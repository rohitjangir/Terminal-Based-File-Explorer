#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <errno.h>
#include <bits/stdc++.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <stack>
#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <fcntl.h>
#include <fstream>
using namespace std;

int first,last;
int endpoint;
void start_normal_mode(string); 


stack<string> s;
stack<string> s1;
vector<string> v;
vector<string> directory;
vector<string> otherfiles;


int sr,sc;
int x;
int accessindex;


struct termios oterm;

void gotoxy(int x,int y)    
{
    printf("%c[%d;%df",0x1B,y,x);
}


void clearscreen()
{
	cout << "\033[H\033[2J\033[3J";
}

bool isdir(const char* path)
{
	struct stat s;
	if(stat(path,&s) == 0)
	{
		if(s.st_mode & S_IFDIR)
		return true;
	}
	return false;
}

string permissions(const char* file)
{
    struct stat st;
    string x1;
    if( stat(file,&st) == 0 )
	{
	    if(st.st_mode & S_IFDIR )
	    {
		x1.push_back('d');
	    }
	}
    if(stat(file, &st) == 0){
	mode_t perm = st.st_mode;
	char c = (perm & S_IRUSR) ? 'r' : '-';
	x1.push_back(c);
	c = (perm & S_IWUSR) ? 'w' : '-';
	x1.push_back(c);
	c = (perm & S_IXUSR) ? 'x' : '-';
	x1.push_back(c);
	c = (perm & S_IRGRP) ? 'r' : '-';
	x1.push_back(c);
	c = (perm & S_IWGRP) ? 'w' : '-';
	x1.push_back(c);
	c = (perm & S_IXGRP) ? 'x' : '-';
	x1.push_back(c);
	c = (perm & S_IROTH) ? 'r' : '-';
	x1.push_back(c);
	c = (perm & S_IWOTH) ? 'w' : '-';
	x1.push_back(c);
	c = (perm & S_IXOTH) ? 'x' : '-';
	x1.push_back(c);
	return x1;     
    }
}

void print_files(const char* cwd)
{
	endpoint =0;
	string path = cwd;
	path += "/";
	for(int i=first;i<last;i++){
		endpoint++;
	string temp1 = path + v[i];
	const char *str = temp1.c_str(); 
	struct stat info;
	stat(str, &info);  // Error check omitted
	struct passwd *pw = getpwuid(info.st_uid);
	string ownername = pw->pw_name;
	struct group  *gr = getgrgid(info.st_gid);
	string group = gr->gr_name;
	int size = info.st_size;
	//convertsize(int);
	string permi = permissions(str);
	string lm = ctime(&info.st_mtime);
	string filename;
	if(v[i].length() >= 20)
	{
		 string temp = v[i];
		 filename = temp.substr(0,18);
		 filename.push_back('.');
		 filename.push_back('.');
	}
	else
	{
		filename = v[i];
		int diff = 20 - v[i].length();
		for(int i=0;i<diff;i++)
		filename += " ";
	}
	float size2 = (float)size/1024;
	string size1 = to_string(size2) + "k";
	string space = "          ";	
	cout<<filename<<space<<size1<<space<<ownername<<space<<group<<space<<permi<<space<<lm;
}}


void disableRawMode() {
  tcsetattr(STDIN_FILENO, TCSAFLUSH, &oterm);
}


void enableRawMode() {
  tcgetattr(STDIN_FILENO, &oterm);
  atexit(disableRawMode);
  struct termios term = oterm;
  term.c_lflag &= ~(ECHO | ICANON);
  tcsetattr(STDIN_FILENO, TCSAFLUSH, &term);
}

void die(const char *s) {
  write(STDOUT_FILENO, "\x1b[2J", 4);
  write(STDOUT_FILENO, "\x1b[H", 3);
  perror(s);
  exit(1);
}


void getcmmd( vector<string> &cmmd,string sttr)
{
	string str;
	for(int i=0;i<sttr.length();i++)
	{
		if(isspace(sttr[i])){
		cmmd.push_back(str);
		str="";}
		else if(sttr[i] == '~')
		continue;
		else
		str.push_back(sttr[i]);
	}
	cmmd.push_back(str);
}


int check(string str)
{
	if(str=="create_file")
        return 1;
    else if(str=="search")
        return 2;
    else if(str=="goto")
        return 3;
    else if(str=="delete_file")
        return 4;
    else if(str=="copy")
        return 5;
    else if(str=="move")
        return 6;
    else if(str=="rename")
        return 7;
    else if(str=="delete_dir")
    	return 8;
	else if(str == "create_dir")
		return 9;
	else
	return 0;
}


bool isabsolute(string str)
{
	string home = "/home";
	int count=0;
	for(int i=0;i<str.size();i++)
	{
		if(home[i] == str[i])
		count++;
	}

	if(count == 5)
	return true;
	return false;
}

void create_file(string str, string str1)
{
	if(isabsolute(str1) == false){		
	str = s.top() + str1 + "/" + str;
	}
	else
	{
	str = str1+ "/" + str;	
	}
	char source[100];
	strcpy(source, str.c_str());
    int fd1 = open(source, O_CREAT, 0);
    chmod(source, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    close(fd1);
	cout<<endl;
}

void delete_file(string str, string str1)
{
	if(isabsolute(str1) == false)
	{
		str = s.top() + str1 + "/" + str;
	}
	else
	{
		str = str1+ "/" + str;
	}
	char Path[100];
	strcpy(Path, str.c_str());
	int fd=remove(Path);
	if(fd==-1){
		cout<<"Problem while deleting file "<<endl;
		exit(0);
	}
	cout<<endl;
}

void copy(const char* home, const char* destination)
{
	ifstream src;
	ofstream dst;
	src.open(home, ios::in | ios::binary);
	dst.open(destination, ios::out | ios::binary);
	dst << src.rdbuf();
	src.close();
	dst.close();
	struct stat st;
	stat(home, &st);
	chmod(destination, st.st_mode);
}

void copy_file(string str, string str1)
{
	if(isabsolute(str1) == false)
	{
		str1 = s.top()+str1+"/"+str;
	}
	else
	str1 = str1 + "/" + str;
	str = s.top()+"/"+str;
	const char* home = str.c_str();
	const char* destination = str1.c_str();
	copy(home,destination);
}


void rename(string str1, string str2)
{
	string x = str1;
	str1 = s.top()+"/"+str1;
	str2 = s.top()+"/"+str2;
	copy(str1.c_str(),str2.c_str());
	delete_file(x,s.top());
}


int remove_d(const char* path1)
{
	DIR *d = opendir(path1);
   size_t path_len = strlen(path1);
   int r = -1;

   if (d) {
      struct dirent *p;

      r = 0;
      while (!r && (p=readdir(d))) {
          int r2 = -1;
          char *buf;
          size_t len;

          /* Skip the names "." and ".." as we don't want to recurse on them. */
          if (!strcmp(p->d_name, ".") || !strcmp(p->d_name, ".."))
             continue;

          len = path_len + strlen(p->d_name) + 2; 
          buf = (char*)malloc(len);

          if (buf) {
             struct stat statbuf;

             snprintf(buf, len, "%s/%s", path1, p->d_name);
             if (!stat(buf, &statbuf)) {
                if (S_ISDIR(statbuf.st_mode))
                   r2 = remove_d(buf);
                else
                   r2 = unlink(buf);
             }
             free(buf);
          }
          r = r2;
      }
      closedir(d);
   }

   if (!r)
      r = rmdir(path1);

   return r;
}


void delete_d(string path)
{
	if(!isabsolute(path))
	{
		path = s.top()+path;
	}
	const char* path1 = path.c_str();
	remove_d(path1);
}

bool search_file(string str)
{     //SEARCH "sfile" in the current directory or list the contens of the given directory
DIR* dir_point;                 //point to the current directory
struct dirent* enter;               //point to one directory entry
struct stat f_details;              //used by lstat()
if ((dir_point=opendir(s.top().c_str()))==NULL){
printf("error trying to open file \n" );
}else{
// scan the directory, traversing each sub-directory, and
while ((enter=readdir(dir_point)))
{
if (enter->d_name && strstr(enter->d_name, str.c_str())) {
	return true;
}
// check if the given entry is a directory.
if (lstat(enter->d_name, &f_details)!=-1){
if ((strcmp(enter->d_name,".")==0 ||  strcmp(enter->d_name, "..") == 0) &&  S_ISDIR(f_details.st_mode)) {
if (chdir(enter->d_name)!= -1){
search_file(enter->d_name);
}}}}}
return false;
}

void create_dir(string str, string str1)
{
	if(str1 ==".")
	str1 = s.top();
	else if(isabsolute(str1) == false)
	{
		str1 = s.top()+str1;
	}
	string test = str1+"/"+str;
	if(search_file(str))
	cout<<"File already present";
	else
	{
		const int dir_err = mkdir(test.c_str(), 0777);
		if (-1 == dir_err)
		{
    		printf("Error creating directory");
    		exit(1);
		}
	}
}


int flag =1;
string sttr="";
void command_mode()
{
	cout<<sttr;
	while(flag)
	{
		char c = cin.get();
		if(c == '\x1b'){
		start_normal_mode(s.top());	
		}
		if(c == 127)
		{
			if(sttr.length() >= 1)
			{
				sttr.pop_back();
				clearscreen();
				gotoxy(0,1);
				print_files(s.top().c_str());
				gotoxy(0,25);
				cout<<"Command Mode"<<endl;
				command_mode();
			}
		}
		if(c == '\x0a')
		{
			vector<string> cmmd;
			//cout<<sttr;
			getcmmd(cmmd,sttr);
			sttr = "";
			int todo = check(cmmd[0]);
			//cout<<cmmd[1];
			switch (todo)
			{
			case 1: create_file(cmmd[1],cmmd[2]);
				break;

			case 2: cout<<endl;
			if(search_file(cmmd[1]))
			cout<<"Yes"<<endl;
			else
			cout<<"No"<<endl;
			break;

			case 4: delete_file(cmmd[1],cmmd[2]);
			break;
			// case 3: gotopath(cmmd[1]);

			case 5: 
			// int dest_add = cmmd.size()-1;
			for(int i=1;i<cmmd.size()-1;i++)
			{
			create_file(cmmd[i],cmmd[cmmd.size()-1]);
			copy_file(cmmd[i],cmmd[cmmd.size()-1]);}
			break;

			case 6: for(int i=1;i<cmmd.size()-1;i++)
			{
				copy_file(cmmd[i],cmmd[cmmd.size()-1]);
				char d[256];
				getcwd(d,256);
				string cwd(d);
				delete_file(cmmd[i],cwd);
			}
			break;
			case 7: rename(cmmd[1],cmmd[2]); break;
			case 8: delete_d(cmmd[1]);
			cout<<endl;
			break;
			case 9: create_dir(cmmd[1],cmmd[2]);
			cout<<endl;
			break;
			default:
				break;
			}
		}

		else
		{
			cout<<c;
			sttr += c;
		}
	}	
}

void editorReadKey() {
    char c;
	c=cin.get();
	if(c == '\x0a')
	{
		string path = s.top();
		path += "/" + v[accessindex-1];
		const char* path1 = path.c_str();
		if(isdir(path1))
		{
			s.push(path);
			start_normal_mode(s.top());
		}
		else{
		pid_t pid = fork();
		if (pid == 0) {
		execlp("xdg-open","xdg-open" , path1, NULL);
		_exit(127);
		};}
	}

	else if(c == 'h')
	{
		s.push("/home/rohit");
		start_normal_mode(s.top());
	}

	else if(c == 'k' && v.size()>20 && accessindex > 0 && x==0)
	{
		clearscreen();
		first--;
		last--;
		accessindex--;
		string str = s.top();
		const char* str1 = str.c_str();
		print_files(str1);
		gotoxy(0,1);
	}

	else if(c == 'l' && v.size() > 20 && accessindex <= v.size())
	{
		clearscreen();
		first++;
		last++;
		accessindex++;
		string str = s.top();
		const char* str1 = str.c_str();
		print_files(str1);
		gotoxy(0,endpoint);
	}

	else if(c == ':')
	{
		gotoxy(0,25);
		cout<<"Command Mode"<<endl;
		command_mode();
	}

	else if(c == 127)
	{
		if(s.top() != "/home/rohit"){
		int count =0;
		string temp1 = s.top();
		string temp = temp1;
		reverse(temp.begin(),temp.end());
		for(int i=0;i<temp.length();i++)
		{
			if(temp[i] == '/')
			break;
			else
			temp1.pop_back();
		}
		temp1.pop_back();
		while(!s.empty())
    	s.pop();
		s.push(temp1);
		start_normal_mode(temp1);
	}
	}
  else if(c == '\x1b')
  {
	  c = cin.get();
	  c = cin.get();
	  switch (c)
	  {
	  case 'A':
	  if(x) 
	  {gotoxy(0,--x);
	  --accessindex;}
	  break;
	  case 'B': if(x < 19) 
	  {gotoxy(0,++x);
	  ++accessindex;}
	  break;
	  case 'C': if(s1.size() >= 2){
	  s.push(s1.top());
	  s1.pop();	  
	  start_normal_mode(s.top());}
	  break;
	  case 'D':
	  if(s.size() >= 2){
	  s1.push(s.top());
	  s.pop();
	  start_normal_mode(s.top());}
	  break; 
	  default:
		  break;
	  }
  }
}

int getWindowSize(int *rows, int *cols) {
  struct winsize ws;
  if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == -1 || ws.ws_col == 0) {
    return -1;
  } else {
    *cols = ws.ws_col;
    *rows = ws.ws_row;
    return 0;
  }
}


void enable_scrolling()
{
	gotoxy(0,1);
	enableRawMode();
  	if(getWindowSize(&sr, &sc) == -1) die("getWindowSize");
	while(true)
	{
		editorReadKey();
	}
}



void displaydir(const char* di)
{
	v.clear();
	DIR* dir = opendir(di); // make seperate function
	if(dir == NULL)
	return; //print error, opendir(d)
	struct dirent* point;
	point = readdir(dir);
	while(point != NULL)
	{
		v.push_back(point->d_name);
		point = readdir(dir);
	}
}

void start_normal_mode(string d)
{
	x=1;
	accessindex=1;
	clearscreen();
	gotoxy(0,1);
	const char *str = d.c_str();
	displaydir(str);
	// get_files(str);
	first =0;
	last = 19>v.size()?v.size():19;
	print_files(str);
	enable_scrolling();
	//while(1);
}


int main()
{
	 // make gobal (forward,backward)
	char d[256];
	getcwd(d,256);
	string cwd(d);
	s.push(cwd);
	//cout<<cwd;
	start_normal_mode(s.top());
}
